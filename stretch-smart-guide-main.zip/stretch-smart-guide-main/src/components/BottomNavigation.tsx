import { useNavigate, useLocation } from "react-router-dom";
import { Home, Calendar, Library, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function BottomNavigation() {
  const navigate = useNavigate();
  const location = useLocation();

  const navItems = [
    { path: "/", icon: Home, label: "Home" },
    { path: "/daily-plan", icon: Calendar, label: "Analysis" },
    { path: "/recovery-plan", icon: Calendar, label: "Recovery" },
    { path: "/exercise-library", icon: Library, label: "Library" },
    { path: "/settings", icon: Settings, label: "Settings" },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border z-50">
      <div className="mobile-container">
        <div className="flex justify-around items-center py-2">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Button
                key={item.path}
                variant="ghost"
                size="sm"
                onClick={() => navigate(item.path)}
                className={`flex flex-col items-center gap-1 h-auto py-2 px-3 ${
                  isActive 
                    ? "text-primary" 
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <item.icon 
                  className={`w-5 h-5 ${isActive ? "text-primary" : ""}`} 
                />
                <span className="text-xs font-medium">{item.label}</span>
              </Button>
            );
          })}
        </div>
      </div>
    </div>
  );
}