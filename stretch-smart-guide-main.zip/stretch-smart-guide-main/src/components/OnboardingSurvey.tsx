import { useState } from "react";
import { useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { ChevronRight, ChevronLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface OnboardingSurveyProps {
  onComplete: () => void;
}

interface FormData {
  age: string;
  gender: string;
  playsports: string;
  sports: string[];
  primarySport: string;
  priorInjury: string;
  injuryDescription: string;
  problemAreas: string;
  stretchFrequency: string;
  trainingPlanDuration: string;
  goals: string;
}

const OnboardingSurvey = ({ onComplete }: OnboardingSurveyProps) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedSports, setSelectedSports] = useState<string[]>([]);
  const { toast } = useToast();
  
  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<FormData>({
    defaultValues: {
      age: "",
      gender: "",
      playsports: "",
      sports: [],
      primarySport: "",
      priorInjury: "",
      injuryDescription: "",
      problemAreas: "",
      stretchFrequency: "",
      trainingPlanDuration: "",
      goals: ""
    }
  });

  const watchedValues = watch();
  const totalSteps = 8;

  const sportsList = [
    "Basketball", "Soccer", "Tennis", "Baseball", "Football", "Swimming", 
    "Running", "Golf", "Volleyball", "Cycling", "Gym/Weight Training", "Other"
  ];

  const handleSportToggle = (sport: string) => {
    const newSports = selectedSports.includes(sport)
      ? selectedSports.filter(s => s !== sport)
      : [...selectedSports, sport];
    
    setSelectedSports(newSports);
    setValue("sports", newSports);
  };

  const onSubmit = async (data: FormData) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        toast({
          title: "Error",
          description: "You must be logged in to complete the survey.",
          variant: "destructive",
        });
        return;
      }

      const { error } = await (supabase as any)
        .from('onboarding_responses')
        .insert({
          user_id: user.id,
          age: parseInt(data.age),
          gender: data.gender,
          plays_sports: data.playsports === "yes",
          sports: selectedSports,
          primary_sport: data.primarySport,
          prior_injury: data.priorInjury === "yes",
          injury_description: data.injuryDescription,
          problem_areas: data.problemAreas,
          stretch_frequency: data.stretchFrequency,
          training_plan_duration: data.trainingPlanDuration,
          goals: data.goals,
        });

      if (error) {
        console.error('Error saving onboarding data:', error);
        toast({
          title: "Error",
          description: "Failed to save your responses. Please try again.",
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "Profile Complete!",
        description: "Welcome to GIDEON. Let's start your recovery journey.",
      });
      onComplete();
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    }
  };

  const nextStep = () => {
    // Skip sports questions if user doesn't play sports
    if (currentStep === 3 && watchedValues.playsports === "no") {
      setCurrentStep(6); // Skip to injury question
      return;
    }
    
    // Skip primary sport question if no sports selected
    if (currentStep === 4 && selectedSports.length === 0) {
      setCurrentStep(6); // Skip to injury question
      return;
    }
    
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="age" className="text-lg font-medium">How old are you?</Label>
              <Input
                id="age"
                type="number"
                placeholder="Enter your age"
                {...register("age", { required: "Age is required" })}
                className="mt-2 h-12"
              />
              {errors.age && <p className="text-destructive text-sm mt-1">{errors.age.message}</p>}
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-4">
            <Label className="text-lg font-medium">What is your gender?</Label>
            <RadioGroup
              value={watchedValues.gender}
              onValueChange={(value) => setValue("gender", value)}
              className="mt-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="male" id="male" />
                <Label htmlFor="male">Male</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="female" id="female" />
                <Label htmlFor="female">Female</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="other" id="other" />
                <Label htmlFor="other">Other</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="prefer-not-to-say" id="prefer-not-to-say" />
                <Label htmlFor="prefer-not-to-say">Prefer not to say</Label>
              </div>
            </RadioGroup>
          </div>
        );

      case 3:
        return (
          <div className="space-y-4">
            <Label className="text-lg font-medium">Do you play sports?</Label>
            <RadioGroup
              value={watchedValues.playsports}
              onValueChange={(value) => setValue("playsports", value)}
              className="mt-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="yes" id="sports-yes" />
                <Label htmlFor="sports-yes">Yes</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="no" id="sports-no" />
                <Label htmlFor="sports-no">No</Label>
              </div>
            </RadioGroup>
          </div>
        );

      case 4:
        return (
          <div className="space-y-4">
            <Label className="text-lg font-medium">What sports do you play?</Label>
            <div className="grid grid-cols-2 gap-3 mt-4">
              {sportsList.map((sport) => (
                <div key={sport} className="flex items-center space-x-2">
                  <Checkbox
                    id={sport}
                    checked={selectedSports.includes(sport)}
                    onCheckedChange={() => handleSportToggle(sport)}
                  />
                  <Label htmlFor={sport} className="text-sm">{sport}</Label>
                </div>
              ))}
            </div>
            {selectedSports.includes("Other") && (
              <Input
                placeholder="Please specify other sport"
                className="mt-2"
              />
            )}
          </div>
        );

      case 5:
        return (
          <div className="space-y-4">
            <Label className="text-lg font-medium">What is your primary sport?</Label>
            <Select onValueChange={(value) => setValue("primarySport", value)}>
              <SelectTrigger className="h-12 mt-2">
                <SelectValue placeholder="Select your primary sport" />
              </SelectTrigger>
              <SelectContent>
                {selectedSports.map((sport) => (
                  <SelectItem key={sport} value={sport}>{sport}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        );

      case 6:
        return (
          <div className="space-y-4">
            <Label className="text-lg font-medium">Have you had any prior injuries?</Label>
            <RadioGroup
              value={watchedValues.priorInjury}
              onValueChange={(value) => setValue("priorInjury", value)}
              className="mt-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="yes" id="injury-yes" />
                <Label htmlFor="injury-yes">Yes</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="no" id="injury-no" />
                <Label htmlFor="injury-no">No</Label>
              </div>
            </RadioGroup>
          </div>
        );

      case 7:
        return (
          <div className="space-y-4">
            {watchedValues.priorInjury === "yes" ? (
              <div>
                <Label htmlFor="injury-description" className="text-lg font-medium">
                  Tell us about your injury
                </Label>
                <Textarea
                  id="injury-description"
                  placeholder="Please describe your injury, when it occurred, and any treatments you've received..."
                  {...register("injuryDescription")}
                  className="mt-2 min-h-[120px]"
                />
              </div>
            ) : (
              <div>
                <Label htmlFor="problem-areas" className="text-lg font-medium">
                  Where are you experiencing problems?
                </Label>
                <Textarea
                  id="problem-areas"
                  placeholder="Describe any areas of discomfort, tightness, or concern..."
                  {...register("problemAreas")}
                  className="mt-2 min-h-[120px]"
                />
              </div>
            )}
          </div>
        );

      case 8:
        return (
          <div className="space-y-6">
            <div>
              <Label className="text-lg font-medium">How often do you stretch?</Label>
              <Select onValueChange={(value) => setValue("stretchFrequency", value)}>
                <SelectTrigger className="h-12 mt-2">
                  <SelectValue placeholder="Select frequency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="few-times-week">A few times a week</SelectItem>
                  <SelectItem value="once-week">Once a week</SelectItem>
                  <SelectItem value="rarely">Rarely</SelectItem>
                  <SelectItem value="never">Never</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-lg font-medium">How long do you want your training plan to be?</Label>
              <Select onValueChange={(value) => setValue("trainingPlanDuration", value)}>
                <SelectTrigger className="h-12 mt-2">
                  <SelectValue placeholder="Select duration" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2-weeks">2 weeks</SelectItem>
                  <SelectItem value="1-month">1 month</SelectItem>
                  <SelectItem value="3-months">3 months</SelectItem>
                  <SelectItem value="6-months">6 months</SelectItem>
                  <SelectItem value="ongoing">Ongoing</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="goals" className="text-lg font-medium">
                What are you looking to get out of GIDEON?
              </Label>
              <Textarea
                id="goals"
                placeholder="Tell us about your goals, what you hope to achieve..."
                {...register("goals")}
                className="mt-2 min-h-[120px]"
              />
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col justify-center">
      <div className="mobile-container px-6 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold gradient-text mb-2">Welcome to GIDEON</h1>
          <p className="text-muted-foreground">
            Let's personalize your experience
          </p>
        </div>

        {/* Progress */}
        <div className="mb-8">
          <div className="flex justify-between text-sm text-muted-foreground mb-2">
            <span>Step {currentStep} of {totalSteps}</span>
            <span>{Math.round((currentStep / totalSteps) * 100)}% complete</span>
          </div>
          <Progress value={(currentStep / totalSteps) * 100} className="h-2" />
        </div>

        {/* Survey Card */}
        <Card className="glass-effect border-0 shadow-orange">
          <CardHeader>
            <CardTitle className="text-xl">Tell us about yourself</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)}>
              {renderStep()}
              
              <div className="flex justify-between mt-8">
                <Button
                  type="button"
                  variant="outline"
                  onClick={prevStep}
                  disabled={currentStep === 1}
                  className="flex items-center gap-2"
                >
                  <ChevronLeft className="w-4 h-4" />
                  Previous
                </Button>

                {currentStep === totalSteps ? (
                  <Button
                    type="submit"
                    className="flex items-center gap-2"
                  >
                    Complete Setup
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                ) : (
                  <Button
                    type="button"
                    onClick={nextStep}
                    className="flex items-center gap-2"
                  >
                    Next
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                )}
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default OnboardingSurvey;