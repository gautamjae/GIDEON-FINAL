
import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Upload, Camera, Play, Square, RotateCcw } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface VideoCaptureProps {
  selectedStretch: {
    id: string;
    name: string;
    category: string;
    difficulty: string;
    duration: string;
    targetMuscles: string[];
    description: string;
  };
  onVideoReady: (videoFile: File) => void;
  onBack: () => void;
}

const VideoCapture = ({ selectedStretch, onVideoReady, onBack }: VideoCaptureProps) => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordedVideo, setRecordedVideo] = useState<string | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Cleanup stream when component unmounts
  useEffect(() => {
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [stream]);

  // Set up video stream when it's available
  useEffect(() => {
    if (stream && videoRef.current) {
      videoRef.current.srcObject = stream;
      videoRef.current.play().catch(console.error);
      setIsCameraActive(true);
    }
  }, [stream]);

  const startCamera = async () => {
    try {
      console.log("Requesting camera access...");
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: 'user',
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }, 
        audio: false 
      });
      
      console.log("Camera access granted, setting up stream...");
      setStream(mediaStream);
      
      toast({
        title: "Camera activated",
        description: "Position yourself in frame and start recording when ready",
      });
    } catch (error) {
      console.error("Camera access error:", error);
      toast({
        title: "Camera access denied",
        description: "Please allow camera access to record your stretch",
        variant: "destructive",
      });
    }
  };

  const startRecording = () => {
    if (!stream) return;
    
    const mediaRecorder = new MediaRecorder(stream);
    mediaRecorderRef.current = mediaRecorder;
    chunksRef.current = [];

    mediaRecorder.ondataavailable = (event) => {
      if (event.data.size > 0) {
        chunksRef.current.push(event.data);
      }
    };

    mediaRecorder.onstop = () => {
      const blob = new Blob(chunksRef.current, { type: 'video/webm' });
      const videoUrl = URL.createObjectURL(blob);
      setRecordedVideo(videoUrl);
      
      // Create File object for analysis
      const file = new File([blob], `${selectedStretch.name}_analysis.webm`, { type: 'video/webm' });
      onVideoReady(file);
    };

    mediaRecorder.start();
    setIsRecording(true);
    toast({
      title: "Recording started",
      description: `Perform your ${selectedStretch.name} stretch now`,
    });
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      toast({
        title: "Recording stopped",
        description: "Processing your video for analysis...",
      });
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.type.startsWith('video/')) {
        onVideoReady(file);
        toast({
          title: "Video uploaded",
          description: "Processing your video for analysis...",
        });
      } else {
        toast({
          title: "Invalid file type",
          description: "Please upload a video file",
          variant: "destructive",
        });
      }
    }
  };

  const resetRecording = () => {
    setRecordedVideo(null);
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
      setIsCameraActive(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <Button variant="outline" onClick={onBack} className="mb-4">
          ← Back to Stretches
        </Button>
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Record Your Stretch</h2>
        <p className="text-gray-600">
          Selected: <span className="font-semibold text-blue-600">{selectedStretch.name}</span>
        </p>
      </div>

      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Camera className="w-5 h-5" />
            Video Analysis Setup
          </CardTitle>
          <CardDescription>
            Record yourself performing the {selectedStretch.name} or upload an existing video
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Video Preview */}
          <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden flex items-center justify-center">
            {isCameraActive && stream ? (
              <video
                ref={videoRef}
                autoPlay
                muted
                playsInline
                className="w-full h-full object-cover transform scale-x-[-1]"
                style={{ transform: 'scaleX(-1)' }}
              />
            ) : recordedVideo ? (
              <video
                src={recordedVideo}
                controls
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="text-center text-gray-500">
                <Camera className="w-16 h-16 mx-auto mb-4 opacity-50" />
                <p>Click "Start Camera" to begin</p>
              </div>
            )}
          </div>

          {/* Recording Controls */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <h4 className="font-semibold text-gray-900">Record New Video</h4>
              <div className="space-y-2">
                {!isCameraActive && (
                  <Button onClick={startCamera} className="w-full" variant="outline">
                    <Camera className="w-4 h-4 mr-2" />
                    Start Camera
                  </Button>
                )}
                {isCameraActive && !isRecording && (
                  <Button onClick={startRecording} className="w-full bg-red-600 hover:bg-red-700">
                    <Play className="w-4 h-4 mr-2" />
                    Start Recording
                  </Button>
                )}
                {isRecording && (
                  <Button onClick={stopRecording} className="w-full bg-gray-600 hover:bg-gray-700">
                    <Square className="w-4 h-4 mr-2" />
                    Stop Recording
                  </Button>
                )}
                {recordedVideo && (
                  <Button onClick={resetRecording} className="w-full" variant="outline">
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Record Again
                  </Button>
                )}
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="font-semibold text-gray-900">Upload Existing Video</h4>
              <input
                ref={fileInputRef}
                type="file"
                accept="video/*"
                onChange={handleFileUpload}
                className="hidden"
              />
              <Button
                onClick={() => fileInputRef.current?.click()}
                className="w-full"
                variant="outline"
              >
                <Upload className="w-4 h-4 mr-2" />
                Choose Video File
              </Button>
            </div>
          </div>

          {/* Instructions */}
          <div className="bg-blue-50 p-4 rounded-lg">
            <h4 className="font-semibold text-blue-900 mb-2">Recording Tips:</h4>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• Ensure good lighting and clear view of your body</li>
              <li>• Perform the stretch slowly and with control</li>
              <li>• Hold the stretch for {selectedStretch.duration}</li>
              <li>• Keep the camera steady throughout recording</li>
              <li>• Make sure your full body is visible in the frame</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default VideoCapture;
