
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Zap, Target, Clock, CheckCircle } from "lucide-react";
import { useState } from "react";

interface Stretch {
  id: string;
  name: string;
  category: string;
  difficulty: "Beginner" | "Intermediate" | "Advanced";
  duration: string;
  targetMuscles: string[];
  description: string;
}

interface StretchSelectorProps {
  onSelectStretch: (stretch: Stretch) => void;
}

const stretches: Stretch[] = [
  {
    id: "1",
    name: "Hamstring Stretch",
    category: "Lower Body",
    difficulty: "Beginner",
    duration: "30-60 seconds",
    targetMuscles: ["Hamstrings", "Calves"],
    description: "Essential for runners and athletes to prevent hamstring injuries"
  },
  {
    id: "2",
    name: "Shoulder Cross-Body Stretch",
    category: "Upper Body",
    difficulty: "Beginner",
    duration: "20-30 seconds",
    targetMuscles: ["Shoulders", "Upper Back"],
    description: "Perfect for office workers and those with shoulder tension"
  },
  {
    id: "3",
    name: "Hip Flexor Stretch",
    category: "Lower Body",
    difficulty: "Intermediate",
    duration: "45-60 seconds",
    targetMuscles: ["Hip Flexors", "Quadriceps"],
    description: "Important for maintaining hip mobility and preventing lower back pain"
  },
  {
    id: "4",
    name: "Thoracic Spine Rotation",
    category: "Back & Spine",
    difficulty: "Intermediate",
    duration: "30-45 seconds",
    targetMuscles: ["Thoracic Spine", "Obliques"],
    description: "Improves spinal mobility and reduces back stiffness"
  },
  {
    id: "5",
    name: "Pigeon Pose",
    category: "Full Body",
    difficulty: "Advanced",
    duration: "60-90 seconds",
    targetMuscles: ["Hip Flexors", "Glutes", "IT Band"],
    description: "Deep hip opener that requires proper form to avoid injury"
  },
  {
    id: "6",
    name: "Neck Side Stretch",
    category: "Upper Body",
    difficulty: "Beginner",
    duration: "15-20 seconds",
    targetMuscles: ["Neck", "Upper Traps"],
    description: "Relieves neck tension and improves cervical mobility"
  }
];

const getDifficultyColor = (difficulty: string) => {
  switch (difficulty) {
    case "Beginner": return "bg-green-100 text-green-800";
    case "Intermediate": return "bg-yellow-100 text-yellow-800";
    case "Advanced": return "bg-red-100 text-red-800";
    default: return "bg-gray-100 text-gray-800";
  }
};

const StretchSelector = ({ onSelectStretch }: StretchSelectorProps) => {
  const [completedStretches, setCompletedStretches] = useState<Set<string>>(new Set());
  
  const handleCompleteStretch = (stretchId: string) => {
    setCompletedStretches(prev => new Set([...prev, stretchId]));
  };

  const availableStretches = stretches.filter(stretch => !completedStretches.has(stretch.id));
  const categories = Array.from(new Set(availableStretches.map(s => s.category)));

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Choose Your Stretch</h2>
        <p className="text-gray-600">Select a stretch to analyze your form and technique</p>
      </div>

      {categories.map(category => (
        <div key={category} className="space-y-4">
          <h3 className="text-xl font-semibold text-gray-800 border-b pb-2">{category}</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {availableStretches.filter(s => s.category === category).map(stretch => (
              <Card key={stretch.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-lg">{stretch.name}</CardTitle>
                    <Badge className={getDifficultyColor(stretch.difficulty)}>
                      {stretch.difficulty}
                    </Badge>
                  </div>
                  <CardDescription className="text-sm">{stretch.description}</CardDescription>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="space-y-3">
                    <div className="flex items-center gap-4 text-sm text-gray-600">
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        <span>{stretch.duration}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Target className="w-4 h-4" />
                        <span>{stretch.targetMuscles.join(", ")}</span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        onClick={() => onSelectStretch(stretch)}
                        className="flex-1 bg-blue-600 hover:bg-blue-700"
                      >
                        <Zap className="w-4 h-4 mr-2" />
                        Analyze This Stretch
                      </Button>
                      <Button 
                        onClick={() => handleCompleteStretch(stretch.id)}
                        variant="outline"
                        size="sm"
                        className="px-3"
                      >
                        <CheckCircle className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};

export default StretchSelector;
