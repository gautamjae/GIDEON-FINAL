
import { useState } from "react";
import BottomNavigation from "@/components/BottomNavigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, Target, CheckCircle, PlayCircle, Flame, LogOut } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface ExerciseTask {
  id: string;
  name: string;
  duration: string;
  sets: string;
  difficulty: "Easy" | "Medium" | "Hard";
  completed: boolean;
  targetMuscles: string[];
  description: string;
}

const Index = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [exercises, setExercises] = useState<ExerciseTask[]>([
    {
      id: "1",
      name: "Morning Neck Stretch",
      duration: "5 minutes",
      sets: "3 sets",
      difficulty: "Easy",
      completed: true,
      targetMuscles: ["Neck", "Upper Traps"],
      description: "Start your day with gentle neck stretches to reduce tension"
    },
    {
      id: "2",
      name: "Hip Flexor Stretch",
      duration: "10 minutes",
      sets: "2 sets each side",
      difficulty: "Medium",
      completed: false,
      targetMuscles: ["Hip Flexors", "Quadriceps"],
      description: "Important for posture and lower back health"
    },
    {
      id: "3",
      name: "Shoulder Blade Squeeze",
      duration: "8 minutes",
      sets: "15 reps x 3",
      difficulty: "Easy",
      completed: false,
      targetMuscles: ["Rhomboids", "Middle Traps"],
      description: "Counter the effects of desk work and poor posture"
    },
    {
      id: "4",
      name: "Hamstring Stretch",
      duration: "12 minutes",
      sets: "Hold 30s x 4",
      difficulty: "Medium",
      completed: false,
      targetMuscles: ["Hamstrings", "Calves"],
      description: "Essential for leg flexibility and injury prevention"
    },
    {
      id: "5",
      name: "Thoracic Spine Mobility",
      duration: "15 minutes",
      sets: "10 reps x 3",
      difficulty: "Hard",
      completed: false,
      targetMuscles: ["Thoracic Spine", "Lats"],
      description: "Advanced mobility work for upper back flexibility"
    }
  ]);

  const completedCount = exercises.filter(ex => ex.completed).length;
  const totalCount = exercises.length;
  const progressPercentage = (completedCount / totalCount) * 100;

  const toggleExerciseCompletion = (id: string) => {
    setExercises(prev => 
      prev.map(ex => 
        ex.id === id ? { ...ex, completed: !ex.completed } : ex
      )
    );
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Easy": return "bg-green-100 text-green-800";
      case "Medium": return "bg-yellow-100 text-yellow-800";
      case "Hard": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut();
      toast({
        title: "Signed out successfully",
        description: "You have been signed out of your account.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to sign out",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="mobile-container px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold gradient-text">GIDEON</h1>
          <Button
            variant="outline"
            size="sm"
            onClick={handleSignOut}
            className="flex items-center gap-2"
          >
            <LogOut className="w-4 h-4" />
          </Button>
        </div>

        <div className="space-y-6">
          {/* Welcome Section */}
          <Card className="glass-effect border-0 shadow-orange overflow-hidden">
            <div className="gradient-orange-yellow p-6 text-white">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <h2 className="text-xl font-bold mb-2">Welcome back!</h2>
                  <p className="text-white/90 text-sm">
                    Ready to continue your recovery journey?
                  </p>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">7</div>
                  <div className="text-xs text-white/80">Day Streak</div>
                </div>
              </div>
            </div>
            <CardContent className="p-4">
              <div className="grid grid-cols-3 gap-4 text-center">
                <div className="space-y-1">
                  <div className="text-lg font-semibold text-primary">12</div>
                  <div className="text-xs text-muted-foreground">Total Sessions</div>
                </div>
                <div className="space-y-1">
                  <div className="text-lg font-semibold text-secondary">4h 20m</div>
                  <div className="text-xs text-muted-foreground">This Week</div>
                </div>
                <div className="space-y-1">
                  <div className="text-lg font-semibold text-primary">85%</div>
                  <div className="text-xs text-muted-foreground">Accuracy</div>
                </div>
              </div>
            </CardContent>
          </Card>
          {/* Progress Overview */}
          <Card className="glass-effect border-0 shadow-orange">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Target className="w-5 h-5 text-primary" />
                Today's Progress
              </CardTitle>
              <CardDescription>
                {new Date(selectedDate).toLocaleDateString('en-US', { 
                  weekday: 'long', 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Completed Exercises</span>
                  <span className="text-sm text-muted-foreground">{completedCount} of {totalCount}</span>
                </div>
                <Progress value={progressPercentage} className="h-3" />
                <div className="grid grid-cols-3 gap-2 mt-4">
                  <div className="flex flex-col items-center gap-1">
                    <Flame className="w-4 h-4 text-primary" />
                    <span className="text-xs">7 days</span>
                  </div>
                  <div className="flex flex-col items-center gap-1">
                    <Clock className="w-4 h-4 text-secondary" />
                    <span className="text-xs">50 min</span>
                  </div>
                  <div className="flex flex-col items-center gap-1">
                    <CheckCircle className="w-4 h-4 text-primary" />
                    <span className="text-xs">Mixed</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Exercise List */}
          <div className="space-y-3">
            {exercises.map((exercise) => (
              <Card key={exercise.id} className={`transition-all border-0 glass-effect ${exercise.completed ? 'bg-primary/10' : 'hover:shadow-orange'}`}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleExerciseCompletion(exercise.id)}
                        className={`p-0 h-6 w-6 rounded-full ${exercise.completed ? 'text-primary' : 'text-muted-foreground'}`}
                      >
                        <CheckCircle className="w-5 h-5" />
                      </Button>
                      <div className="flex-1">
                        <CardTitle className={`text-base ${exercise.completed ? 'line-through text-muted-foreground' : ''}`}>
                          {exercise.name}
                        </CardTitle>
                        <CardDescription className="mt-1 text-xs">
                          {exercise.description}
                        </CardDescription>
                      </div>
                    </div>
                    <Badge className={`${getDifficultyColor(exercise.difficulty)} text-xs`}>
                      {exercise.difficulty}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        <span>{exercise.duration}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Target className="w-3 h-3" />
                        <span>{exercise.sets}</span>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => navigate("/exercise-library")}
                      className="flex items-center gap-1 text-xs h-8"
                    >
                      <PlayCircle className="w-3 h-3" />
                      Start
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Motivational Section */}
          <Card className="bg-primary/10 border-0 shadow-orange">
            <CardContent className="pt-6">
              <div className="text-center">
                <h3 className="text-lg font-semibold mb-2">
                  {progressPercentage === 100 ? "Great job! 🎉" : "Keep it up! 💪"}
                </h3>
                <p className="text-muted-foreground text-sm">
                  {progressPercentage === 100 
                    ? "You've completed all exercises for today. Your consistency is building stronger, healthier movement patterns!"
                    : `You're ${Math.round(progressPercentage)}% through today's plan. Every stretch brings you closer to better mobility and injury prevention.`
                  }
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <BottomNavigation />
    </div>
  );
};

export default Index;
