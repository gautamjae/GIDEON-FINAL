
import { useState } from "react";
import { Button } from "@/components/ui/button";
import BottomNavigation from "@/components/BottomNavigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { User, Bell, Shield, Camera, Save, ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";

const Settings = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [settings, setSettings] = useState({
    name: "John Doe",
    email: "john@example.com",
    notifications: true,
    cameraPermission: true,
    autoSave: false,
    theme: "light"
  });

  const handleSaveSettings = () => {
    // In a real app, this would save to a database
    toast({
      title: "Settings saved",
      description: "Your preferences have been updated successfully.",
    });
  };

  const updateSetting = (key: string, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="mobile-container px-4 py-8">
        <div className="flex items-center gap-4 mb-6">
          <Button 
            variant="outline" 
            onClick={() => navigate("/")}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </Button>
          <h1 className="text-2xl font-bold gradient-text">Settings</h1>
        </div>

        <div className="space-y-6">
          <Tabs defaultValue="profile" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4 h-10">
              <TabsTrigger value="profile" className="text-xs">Profile</TabsTrigger>
              <TabsTrigger value="preferences" className="text-xs">Prefs</TabsTrigger>
              <TabsTrigger value="privacy" className="text-xs">Privacy</TabsTrigger>
              <TabsTrigger value="about" className="text-xs">About</TabsTrigger>
            </TabsList>

            <TabsContent value="profile">
              <Card className="glass-effect border-0 shadow-orange">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <User className="w-5 h-5 text-primary" />
                    Profile Information
                  </CardTitle>
                  <CardDescription>
                    Update your personal information and preferences.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name</Label>
                      <Input
                        id="name"
                        value={settings.name}
                        onChange={(e) => updateSetting("name", e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={settings.email}
                        onChange={(e) => updateSetting("email", e.target.value)}
                      />
                    </div>
                  </div>
                  <Button onClick={handleSaveSettings} className="gradient-orange-yellow text-white flex items-center gap-2">
                    <Save className="w-4 h-4" />
                    Save Changes
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="preferences">
              <Card className="glass-effect border-0 shadow-orange">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Bell className="w-5 h-5 text-primary" />
                    App Preferences
                  </CardTitle>
                  <CardDescription>
                    Configure how the app behaves and looks.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Push Notifications</Label>
                      <p className="text-sm text-muted-foreground">Receive notifications about your exercise reminders</p>
                    </div>
                    <Switch
                      checked={settings.notifications}
                      onCheckedChange={(checked) => updateSetting("notifications", checked)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Auto-save Analysis</Label>
                      <p className="text-sm text-muted-foreground">Automatically save your exercise analysis results</p>
                    </div>
                    <Switch
                      checked={settings.autoSave}
                      onCheckedChange={(checked) => updateSetting("autoSave", checked)}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="privacy">
              <Card className="glass-effect border-0 shadow-orange">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Shield className="w-5 h-5 text-primary" />
                    Privacy & Security
                  </CardTitle>
                  <CardDescription>
                    Manage your privacy settings and permissions.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Camera Permission</Label>
                      <p className="text-sm text-muted-foreground">Allow access to camera for video analysis</p>
                    </div>
                    <Switch
                      checked={settings.cameraPermission}
                      onCheckedChange={(checked) => updateSetting("cameraPermission", checked)}
                    />
                  </div>
                  <div className="bg-secondary/20 p-4 rounded-lg">
                    <h4 className="font-semibold text-secondary mb-2">Data Usage</h4>
                    <p className="text-sm text-muted-foreground">
                      Your video data is processed locally and never stored on our servers. 
                      Analysis results are kept only for your personal use.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="about">
              <Card className="glass-effect border-0 shadow-orange">
                <CardHeader>
                  <CardTitle>About GIDEON</CardTitle>
                  <CardDescription>
                    Version 1.0.0 - Your AI-powered injury prevention companion
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <h4 className="font-semibold">Features</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• AI-powered video analysis for exercise form</li>
                      <li>• Personalized feedback and recommendations</li>
                      <li>• Daily exercise plans tailored to your needs</li>
                      <li>• Comprehensive exercise library with professional guidance</li>
                    </ul>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-semibold">Support</h4>
                    <p className="text-sm text-muted-foreground">
                      For help and support, please contact our team at support@gideon.com
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
      
      <BottomNavigation />
    </div>
  );
};

export default Settings;
