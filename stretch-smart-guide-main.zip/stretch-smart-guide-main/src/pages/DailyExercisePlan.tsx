
import { useState } from "react";
import StretchSelector from "@/components/StretchSelector";
import VideoCapture from "@/components/VideoCapture";
import AnalysisResults from "@/components/AnalysisResults";
import BottomNavigation from "@/components/BottomNavigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, Zap, TrendingUp, Users, LogOut } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";

interface Stretch {
  id: string;
  name: string;
  category: string;
  difficulty: string;
  duration: string;
  targetMuscles: string[];
  description: string;
}

type AppState = "welcome" | "selecting" | "recording" | "analyzing";

const DailyExercisePlan = () => {
  const [appState, setAppState] = useState<AppState>("welcome");
  const [selectedStretch, setSelectedStretch] = useState<Stretch | null>(null);
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleSelectStretch = (stretch: Stretch) => {
    setSelectedStretch(stretch);
    setAppState("recording");
  };

  const handleVideoReady = (file: File) => {
    setVideoFile(file);
    setAppState("analyzing");
  };

  const handleStartOver = () => {
    setSelectedStretch(null);
    setVideoFile(null);
    setAppState("selecting");
  };

  const startAnalysis = () => {
    setAppState("selecting");
  };

  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut();
      toast({
        title: "Signed out successfully",
        description: "You have been signed out of your account.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to sign out",
        variant: "destructive"
      });
    }
  };

  if (appState === "welcome") {
    return (
      <div className="min-h-screen bg-background pb-20">
        <div className="mobile-container px-4 py-8">
          {/* Header with Sign Out */}
          <div className="flex justify-end items-center mb-6">
            <Button
              variant="outline"
              size="sm"
              onClick={handleSignOut}
              className="flex items-center gap-2"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">Sign Out</span>
            </Button>
          </div>

          {/* Hero Section */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-20 h-20 gradient-orange-yellow rounded-full mb-6 shadow-orange">
              <Shield className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold gradient-text mb-4">
              GIDEON
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
              Your AI-powered injury prevention companion. Analyze your stretching technique, 
              get personalized feedback, and improve your form to prevent injuries and enhance recovery.
            </p>
            <Button
              onClick={startAnalysis}
              size="lg"
              className="gradient-orange-yellow text-white px-8 py-4 text-lg font-semibold shadow-orange hover:shadow-lg transition-all duration-300"
            >
              Start Your Analysis
            </Button>
          </div>

          {/* Features */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-12">
            <Card className="text-center hover:shadow-orange transition-all duration-300 border-0 glass-effect">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Zap className="w-6 h-6 text-primary" />
                </div>
                <CardTitle className="text-lg">AI Video Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Advanced computer vision analyzes your stretching form in real-time
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-orange transition-all duration-300 border-0 glass-effect">
              <CardHeader>
                <div className="w-12 h-12 bg-secondary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="w-6 h-6 text-secondary" />
                </div>
                <CardTitle className="text-lg">Personalized Feedback</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Get specific recommendations tailored to your unique movement patterns
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-orange transition-all duration-300 border-0 glass-effect">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-6 h-6 text-primary" />
                </div>
                <CardTitle className="text-lg">Injury Prevention</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Identify potential injury risks and learn proper techniques to stay safe
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-orange transition-all duration-300 border-0 glass-effect">
              <CardHeader>
                <div className="w-12 h-12 bg-secondary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-6 h-6 text-secondary" />
                </div>
                <CardTitle className="text-lg">Expert Guidance</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Access professional-grade insights based on sports medicine principles
                </CardDescription>
              </CardContent>
            </Card>
          </div>

          {/* How It Works */}
          <div className="bg-card rounded-3xl p-8 shadow-orange border-0">
            <h2 className="text-3xl font-bold text-center mb-8 gradient-text">How It Works</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 gradient-orange-yellow rounded-full flex items-center justify-center mx-auto mb-4 text-white text-2xl font-bold shadow-orange">1</div>
                <h3 className="text-xl font-semibold mb-3">Choose Your Stretch</h3>
                <p className="text-muted-foreground">Select from our library of stretches or input your own routine</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 gradient-orange-yellow rounded-full flex items-center justify-center mx-auto mb-4 text-white text-2xl font-bold shadow-orange">2</div>
                <h3 className="text-xl font-semibold mb-3">Record or Upload</h3>
                <p className="text-muted-foreground">Capture your stretching session using your camera or upload an existing video</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 gradient-orange-yellow rounded-full flex items-center justify-center mx-auto mb-4 text-white text-2xl font-bold shadow-orange">3</div>
                <h3 className="text-xl font-semibold mb-3">Get Feedback</h3>
                <p className="text-muted-foreground">Receive detailed analysis and personalized recommendations for improvement</p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Bottom Navigation */}
        <BottomNavigation />
      </div>
    );
  }

  if (appState === "selecting") {
    return (
      <div className="min-h-screen bg-background">
        <div className="mobile-container px-4 py-8">
          <div className="flex justify-end mb-4">
            <Button
              variant="outline"
              onClick={handleSignOut}
              className="flex items-center gap-2"
            >
              <LogOut className="w-4 h-4" />
              Sign Out
            </Button>
          </div>
          <StretchSelector onSelectStretch={handleSelectStretch} />
        </div>
      </div>
    );
  }

  if (appState === "recording" && selectedStretch) {
    return (
      <div className="min-h-screen bg-background">
        <div className="mobile-container px-4 py-8">
          <div className="flex justify-end mb-4">
            <Button
              variant="outline"
              onClick={handleSignOut}
              className="flex items-center gap-2"
            >
              <LogOut className="w-4 h-4" />
              Sign Out
            </Button>
          </div>
          <VideoCapture
            selectedStretch={selectedStretch}
            onVideoReady={handleVideoReady}
            onBack={() => setAppState("selecting")}
          />
        </div>
      </div>
    );
  }

  if (appState === "analyzing" && selectedStretch && videoFile) {
    return (
      <div className="min-h-screen bg-background">
        <div className="mobile-container px-4 py-8">
          <div className="flex justify-end mb-4">
            <Button
              variant="outline"
              onClick={handleSignOut}
              className="flex items-center gap-2"
            >
              <LogOut className="w-4 h-4" />
              Sign Out
            </Button>
          </div>
          <AnalysisResults
            selectedStretch={selectedStretch}
            videoFile={videoFile}
            onStartOver={handleStartOver}
          />
        </div>
      </div>
    );
  }

  return null;
};

export default DailyExercisePlan;
