import { useState } from "react";
import BottomNavigation from "@/components/BottomNavigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar } from "@/components/ui/calendar";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Calendar as CalendarIcon, Clock, Target, TrendingUp, Heart, Activity, LogOut, CheckCircle } from "lucide-react";
import { format, isSameDay, subDays } from "date-fns";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface RecoveryPhase {
  id: string;
  name: string;
  duration: string;
  status: "completed" | "current" | "upcoming";
  progress: number;
  description: string;
  activities: string[];
}

const RecoveryPlan = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  
  // Mock completed exercise days (last 7 days with some completed)
  const completedDays = [
    subDays(new Date(), 1), // Yesterday
    subDays(new Date(), 2), // 2 days ago
    subDays(new Date(), 4), // 4 days ago
    subDays(new Date(), 6), // 6 days ago
  ];
  
  const [recoveryPhases] = useState<RecoveryPhase[]>([
    {
      id: "1",
      name: "Initial Rest & Ice",
      duration: "Days 1-3",
      status: "completed",
      progress: 100,
      description: "Focus on reducing inflammation and pain",
      activities: ["Ice therapy", "Gentle movement", "Pain management"]
    },
    {
      id: "2",
      name: "Early Mobility",
      duration: "Days 4-7",
      status: "current",
      progress: 65,
      description: "Begin gentle range of motion exercises",
      activities: ["Gentle stretching", "Basic mobility", "Light movement"]
    },
    {
      id: "3",
      name: "Strength Building",
      duration: "Week 2-3",
      status: "upcoming",
      progress: 0,
      description: "Progressive strengthening and stability",
      activities: ["Resistance exercises", "Balance training", "Functional movement"]
    },
    {
      id: "4",
      name: "Return to Activity",
      duration: "Week 4+",
      status: "upcoming",
      progress: 0,
      description: "Gradual return to normal activities",
      activities: ["Sport-specific training", "Full ROM", "Performance testing"]
    }
  ]);

  const currentPhase = recoveryPhases.find(phase => phase.status === "current");
  const overallProgress = recoveryPhases.reduce((acc, phase) => acc + phase.progress, 0) / recoveryPhases.length;

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed": return "bg-green-100 text-green-800";
      case "current": return "bg-primary/20 text-primary";
      case "upcoming": return "bg-muted text-muted-foreground";
      default: return "bg-muted text-muted-foreground";
    }
  };

  const isCompletedDay = (date: Date) => {
    return completedDays.some(completedDay => isSameDay(date, completedDay));
  };

  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut();
      toast({
        title: "Signed out successfully",
        description: "You have been signed out of your account.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to sign out",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="mobile-container px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold gradient-text">Recovery Plan</h1>
          <Button
            variant="outline"
            size="sm"
            onClick={handleSignOut}
            className="flex items-center gap-2"
          >
            <LogOut className="w-4 h-4" />
          </Button>
        </div>

        <div className="space-y-6">
          {/* Overall Progress */}
          <Card className="glass-effect border-0 shadow-orange">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Heart className="w-5 h-5 text-primary" />
                Recovery Progress
              </CardTitle>
              <CardDescription>
                Your journey back to full mobility and strength
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Overall Recovery</span>
                  <span className="text-sm text-muted-foreground">{Math.round(overallProgress)}%</span>
                </div>
                <Progress value={overallProgress} className="h-3" />
                <div className="grid grid-cols-3 gap-2 mt-4">
                  <div className="flex flex-col items-center gap-1">
                    <Activity className="w-4 h-4 text-primary" />
                    <span className="text-xs">Week 2</span>
                  </div>
                  <div className="flex flex-col items-center gap-1">
                    <Target className="w-4 h-4 text-secondary" />
                    <span className="text-xs">4 phases</span>
                  </div>
                  <div className="flex flex-col items-center gap-1">
                    <TrendingUp className="w-4 h-4 text-primary" />
                    <span className="text-xs">On track</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Calendar */}
          <Card className="glass-effect border-0 shadow-orange">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <CalendarIcon className="w-5 h-5 text-primary" />
                Recovery Calendar
              </CardTitle>
              <CardDescription>
                Track your daily progress and milestones
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                className="rounded-md border-0 p-3 pointer-events-auto"
                components={{
                  DayContent: ({ date }) => (
                    <div className="relative w-full h-full flex items-center justify-center">
                      <span>{date.getDate()}</span>
                      {isCompletedDay(date) && (
                        <CheckCircle className="absolute -top-1 -right-1 w-3 h-3 text-green-500 fill-current" />
                      )}
                    </div>
                  )
                }}
              />
              {selectedDate && (
                <div className="mt-4 p-4 bg-primary/10 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <h4 className="font-semibold text-sm">
                      {format(selectedDate, "EEEE, MMMM d, yyyy")}
                    </h4>
                    {isCompletedDay(selectedDate) && (
                      <CheckCircle className="w-4 h-4 text-green-500" />
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {isCompletedDay(selectedDate) 
                      ? "✓ Exercises completed on this day" 
                      : currentPhase 
                        ? `${currentPhase.name}: ${currentPhase.description}` 
                        : "Continue your recovery plan"
                    }
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recovery Phases */}
          <div className="space-y-3">
            <h2 className="text-lg font-semibold mb-4">Recovery Phases</h2>
            {recoveryPhases.map((phase) => (
              <Card key={phase.id} className={`transition-all border-0 glass-effect ${phase.status === 'current' ? 'ring-2 ring-primary/50' : ''}`}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <CardTitle className="text-base">{phase.name}</CardTitle>
                        <Badge className={`${getStatusColor(phase.status)} text-xs`}>
                          {phase.status === 'current' ? 'Current' : phase.status}
                        </Badge>
                      </div>
                      <CardDescription className="text-xs mb-2">
                        {phase.description}
                      </CardDescription>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Clock className="w-3 h-3" />
                        <span>{phase.duration}</span>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-medium">Progress</span>
                      <span className="text-xs text-muted-foreground">{phase.progress}%</span>
                    </div>
                    <Progress value={phase.progress} className="h-2" />
                    <div className="flex flex-wrap gap-1">
                      {phase.activities.map((activity, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {activity}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Current Phase Focus */}
          {currentPhase && (
            <Card className="bg-primary/10 border-0 shadow-orange">
              <CardContent className="pt-6">
                <div className="text-center">
                  <h3 className="text-lg font-semibold mb-2">Current Focus</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    {currentPhase.description}
                  </p>
                  <Button 
                    onClick={() => navigate("/")}
                    className="gradient-orange-yellow text-white"
                  >
                    View Today's Exercises
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
      
      <BottomNavigation />
    </div>
  );
};

export default RecoveryPlan;