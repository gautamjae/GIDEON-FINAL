
import { useState } from "react";
import BottomNavigation from "@/components/BottomNavigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Play, Clock, Target, User, ArrowLeft, BookOpen } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface Exercise {
  id: string;
  name: string;
  category: string;
  difficulty: "Beginner" | "Intermediate" | "Advanced";
  duration: string;
  targetMuscles: string[];
  description: string;
  videoUrl: string;
  therapistName: string;
  scienceExplanation: string;
  benefits: string[];
  instructions: string[];
}

const ExerciseLibrary = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const exercises: Exercise[] = [
    {
      id: "1",
      name: "Cervical Spine Flexion",
      category: "Neck & Shoulders",
      difficulty: "Beginner",
      duration: "2-3 minutes",
      targetMuscles: ["Cervical Extensors", "Upper Trapezius"],
      description: "Gentle forward neck flexion to relieve tension in the posterior neck muscles",
      videoUrl: "https://example.com/cervical-flexion.mp4",
      therapistName: "Dr. Sarah Martinez, DPT",
      scienceExplanation: "This stretch targets the cervical extensors and upper trapezius muscles, which often become tight from prolonged forward head posture. The gentle flexion helps restore normal cervical lordosis and reduces muscle tension.",
      benefits: ["Reduces neck pain", "Improves posture", "Increases cervical mobility"],
      instructions: [
        "Sit upright with shoulders relaxed",
        "Slowly lower your chin toward your chest",
        "Feel the stretch along the back of your neck",
        "Hold for 30 seconds, repeat 3 times"
      ]
    },
    {
      id: "2",
      name: "Thoracic Extension Mobility",
      category: "Back & Spine",
      difficulty: "Intermediate",
      duration: "5-7 minutes",
      targetMuscles: ["Thoracic Extensors", "Latissimus Dorsi"],
      description: "Targeted mobility work for the thoracic spine to counteract kyphotic posture",
      videoUrl: "https://example.com/thoracic-extension.mp4",
      therapistName: "Dr. Michael Chen, DPT, OCS",
      scienceExplanation: "The thoracic spine naturally has a kyphotic curve, but modern lifestyles often increase this curve excessively. This exercise promotes extension to restore balance and reduce compensatory patterns in the cervical and lumbar spine.",
      benefits: ["Improves thoracic mobility", "Reduces upper back stiffness", "Enhances breathing capacity"],
      instructions: [
        "Use a foam roller or towel under your upper back",
        "Support your head with your hands",
        "Gently extend backward over the roller",
        "Hold for 30 seconds, repeat 5 times"
      ]
    },
    {
      id: "3",
      name: "Hip Flexor Stretch - Couch Stretch",
      category: "Hips & Pelvis",
      difficulty: "Advanced",
      duration: "8-10 minutes",
      targetMuscles: ["Hip Flexors", "Psoas", "Rectus Femoris"],
      description: "Deep hip flexor stretch using a couch or elevated surface for maximum effectiveness",
      videoUrl: "https://example.com/couch-stretch.mp4",
      therapistName: "Dr. Amanda Rodriguez, DPT, CSCS",
      scienceExplanation: "The hip flexors, particularly the psoas and rectus femoris, become adaptively shortened from prolonged sitting. This stretch addresses both the hip flexor complex and the anterior hip capsule, promoting better hip extension and reducing anterior pelvic tilt.",
      benefits: ["Improves hip extension", "Reduces lower back pain", "Enhances athletic performance"],
      instructions: [
        "Place rear foot on elevated surface",
        "Step forward into lunge position",
        "Drive hips forward and down",
        "Hold for 2 minutes each side"
      ]
    },
    {
      id: "4",
      name: "Posterior Shoulder Capsule Stretch",
      category: "Neck & Shoulders",
      difficulty: "Beginner",
      duration: "3-4 minutes",
      targetMuscles: ["Posterior Deltoid", "Posterior Capsule"],
      description: "Cross-body shoulder stretch to improve posterior shoulder flexibility",
      videoUrl: "https://example.com/shoulder-stretch.mp4",
      therapistName: "Dr. Jessica Thompson, DPT",
      scienceExplanation: "The posterior shoulder capsule often becomes tight in overhead athletes and desk workers. This stretch helps restore normal glenohumeral joint mobility and reduces the risk of impingement syndrome.",
      benefits: ["Increases shoulder mobility", "Reduces shoulder pain", "Improves overhead reach"],
      instructions: [
        "Bring arm across your body",
        "Use opposite hand to pull arm closer",
        "Keep shoulders level",
        "Hold for 30 seconds, repeat 3 times each arm"
      ]
    },
    {
      id: "5",
      name: "Piriformis Stretch - Figure 4",
      category: "Hips & Pelvis",
      difficulty: "Intermediate",
      duration: "4-5 minutes",
      targetMuscles: ["Piriformis", "Deep Hip Rotators"],
      description: "Targeted stretch for the piriformis muscle to relieve sciatic nerve compression",
      videoUrl: "https://example.com/piriformis-stretch.mp4",
      therapistName: "Dr. Robert Kim, DPT, PhD",
      scienceExplanation: "The piriformis muscle can compress the sciatic nerve when tight, causing pain and numbness. This stretch specifically targets the piriformis and other deep hip rotators, helping to decompress the sciatic nerve and improve hip function.",
      benefits: ["Reduces sciatic pain", "Improves hip rotation", "Enhances pelvic stability"],
      instructions: [
        "Lie on your back",
        "Cross ankle over opposite knee",
        "Pull thigh toward chest",
        "Hold for 45 seconds each side"
      ]
    },
    {
      id: "6",
      name: "Calf Stretch - Gastrocnemius",
      category: "Lower Extremity",
      difficulty: "Beginner",
      duration: "2-3 minutes",
      targetMuscles: ["Gastrocnemius", "Soleus"],
      description: "Wall-supported calf stretch targeting the gastrocnemius muscle",
      videoUrl: "https://example.com/calf-stretch.mp4",
      therapistName: "Dr. Lisa Park, DPT",
      scienceExplanation: "The gastrocnemius muscle crosses both the knee and ankle joints, making it prone to tightness. This stretch helps maintain ankle dorsiflexion range of motion, which is crucial for normal gait and reducing the risk of plantar fasciitis.",
      benefits: ["Improves ankle mobility", "Reduces calf tightness", "Prevents plantar fasciitis"],
      instructions: [
        "Place hands against wall",
        "Step back with one foot",
        "Keep heel down and leg straight",
        "Hold for 30 seconds each leg"
      ]
    }
  ];

  const categories = ["all", ...Array.from(new Set(exercises.map(ex => ex.category)))];

  const filteredExercises = exercises.filter(exercise => {
    const matchesSearch = exercise.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         exercise.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         exercise.targetMuscles.some(muscle => muscle.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = selectedCategory === "all" || exercise.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner": return "bg-green-100 text-green-800";
      case "Intermediate": return "bg-yellow-100 text-yellow-800";
      case "Advanced": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="mobile-container px-4 py-8">
        <div className="flex items-center gap-4 mb-6">
          <Button 
            variant="outline" 
            onClick={() => navigate("/")}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </Button>
          <h1 className="text-2xl font-bold gradient-text">Exercise Library</h1>
        </div>

        <div className="space-y-6">
          {/* Search and Filter */}
          <Card className="glass-effect border-0 shadow-orange">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Search className="w-5 h-5 text-primary" />
                Find Your Exercise
              </CardTitle>
              <CardDescription>
                Search through our professional exercise library with expert guidance
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Input
                  placeholder="Search exercises, muscles, or techniques..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full"
                />
                <div className="flex gap-2 flex-wrap">
                  {categories.map(category => (
                    <Button
                      key={category}
                      variant={selectedCategory === category ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedCategory(category)}
                      className={selectedCategory === category ? "gradient-orange-yellow text-white" : ""}
                    >
                      {category === "all" ? "All" : category}
                    </Button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Exercise Grid */}
          <div className="space-y-4">
            {filteredExercises.map((exercise) => (
              <Card key={exercise.id} className="glass-effect border-0 hover:shadow-orange transition-all">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start mb-2">
                    <Badge className={getDifficultyColor(exercise.difficulty)}>
                      {exercise.difficulty}
                    </Badge>
                    <Badge variant="outline">{exercise.category}</Badge>
                  </div>
                  <CardTitle className="text-lg">{exercise.name}</CardTitle>
                  <CardDescription className="text-sm">{exercise.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      <span>{exercise.duration}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Target className="w-4 h-4" />
                      <span>{exercise.targetMuscles.slice(0, 2).join(", ")}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2 text-sm">
                    <User className="w-4 h-4 text-primary" />
                    <span className="font-medium text-primary">{exercise.therapistName}</span>
                  </div>

                  <Tabs defaultValue="overview" className="w-full">
                    <TabsList className="grid w-full grid-cols-3 h-8">
                      <TabsTrigger value="overview" className="text-xs">Overview</TabsTrigger>
                      <TabsTrigger value="science" className="text-xs">Science</TabsTrigger>
                      <TabsTrigger value="steps" className="text-xs">Steps</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="overview" className="space-y-2 mt-3">
                      <h4 className="font-semibold text-sm">Benefits:</h4>
                      <ul className="text-xs space-y-1">
                        {exercise.benefits.map((benefit, index) => (
                          <li key={index} className="flex items-start gap-1">
                            <span className="text-primary mt-0.5">•</span>
                            <span>{benefit}</span>
                          </li>
                        ))}
                      </ul>
                    </TabsContent>
                    
                    <TabsContent value="science" className="space-y-2 mt-3">
                      <h4 className="font-semibold text-sm flex items-center gap-1">
                        <BookOpen className="w-3 h-3" />
                        Scientific Background:
                      </h4>
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        {exercise.scienceExplanation}
                      </p>
                    </TabsContent>
                    
                    <TabsContent value="steps" className="space-y-2 mt-3">
                      <h4 className="font-semibold text-sm">Instructions:</h4>
                      <ol className="text-xs space-y-1">
                        {exercise.instructions.map((step, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <span className="bg-primary/20 text-primary rounded-full w-4 h-4 flex items-center justify-center text-xs font-medium mt-0.5">
                              {index + 1}
                            </span>
                            <span>{step}</span>
                          </li>
                        ))}
                      </ol>
                    </TabsContent>
                  </Tabs>

                  <div className="flex gap-2 pt-2">
                    <Button 
                      size="sm" 
                      className="flex-1 gradient-orange-yellow text-white"
                      onClick={() => navigate("/")}
                    >
                      <Play className="w-4 h-4 mr-2" />
                      Watch Demo
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => navigate("/")}
                    >
                      Try It
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredExercises.length === 0 && (
            <Card className="text-center py-8 glass-effect border-0">
              <CardContent>
                <Search className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-semibold mb-2">No exercises found</h3>
                <p className="text-muted-foreground">Try adjusting your search terms or category filter</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
      
      <BottomNavigation />
    </div>
  );
};

export default ExerciseLibrary;
